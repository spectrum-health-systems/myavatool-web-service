﻿Public Class FieldObject

    Public Enabled As String

    Public FieldNumber As String

    Public FieldValue As String

    Public Lock As String

    Public Required As String

End Class
