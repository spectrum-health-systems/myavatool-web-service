﻿Public Class OptionObject2

    Public EntityID As String

    Public EpisodeNumber As Double

    Public ErrorCode As Double

    Public ErrorMesg As String

    Public Facility As String

    Public Forms() As FormObject

    Public NamespaceName As String

    Public OptionId As String

    Public OptionStaffId As String

    Public OptionUserId As String

    Public ParentNamespace As String

    Public ServerName As String

    Public SystemCode As String


End Class
